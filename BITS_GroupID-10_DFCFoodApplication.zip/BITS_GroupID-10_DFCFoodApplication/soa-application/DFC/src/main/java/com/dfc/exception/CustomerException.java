package com.foodyexpress.exception;

public class CustomerException extends Exception {

	public CustomerException() {
		// TODO Auto-generated constructor stub
	}

	public CustomerException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}

}

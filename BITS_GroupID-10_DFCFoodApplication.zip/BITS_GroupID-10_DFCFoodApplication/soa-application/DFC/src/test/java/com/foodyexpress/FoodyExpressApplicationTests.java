package com.foodyexpress;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoodyExpressApplicationTests {

	@Test
	void contextLoads() {
	}

}
